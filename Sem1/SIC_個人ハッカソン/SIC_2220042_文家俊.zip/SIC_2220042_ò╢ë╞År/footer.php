    <footer>
        <p>メール: Cyrusstudio@gmail.com &nbsp; &nbsp; 電話番号: +81 06-6233-9187</p>
        <p id="Copyright">&copy; <?php echo date('Y')?>  All rights reserved.</p>
    </footer>
</html>