<?php
    $brank = 
    [
        [
            'name' => 'Canon',
            'image' => '<img src="./image/Logo/Canon.png">',
        ],
        [
            'name' => 'Nikon',
            'image' => '<img src="./image/Logo/Nikon.png">',
        ],
        [
            'name' => 'Sony',
            'image' => '<img src="./image/Logo/Sony.png">',
        ],
        [ 
            'name' => 'Fujifilm',
            'image' => '<img src="./image/Logo/Fujifilm.png">',
        ],
        [
            'name' => 'Leica',
            'image' => '<img src="./image/Logo/Leica.png">',
        ],
    ]
?>