<?php include_once('header.php'); ?>

    <div id="about">
        <P>時間がない</P>
    </div>

<?php include_once('footer.php'); ?>