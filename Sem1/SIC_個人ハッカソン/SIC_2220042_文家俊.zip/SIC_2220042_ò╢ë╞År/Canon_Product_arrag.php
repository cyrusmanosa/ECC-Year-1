<?php
//到MySQL部份，我們將會這些資料放到資料庫裏
$CLP= 
[
    [
        'gem_id' => 1,
        'name'=>  'Canon EF-S 10-18mm f/4.5-5.6 IS STM',
        'price' => 10000,
        'image' => '<img src="./image/Product/Canon/Canon-Lens/Canon_10-18mm_f4.5-5.6_IS_STM_01.jpg">',
        'remaining' =>  5
    ],
    [
        'gem_id'    =>  2,
        'name'      => 'Canon EF 85mm f/1.4L IS USM',
        'price' => 10000,
        'image' => '<img src="./image/Product/Canon/Canon-Lens/Canon_85mm_f1.4_IS_01.jpg">',
        'remaining' =>  5
    ],
    [
        'gem_id' =>  3,
        'name' => 'Canon RF 24-70mm f/2.8L IS USM',
        'price' => 10000,
        'image' => '<img src="./image/Product/Canon/Canon-Lens/Canon_24-70mm_f2.8_IS_01.jpg">',
        'remaining' =>  5
    ],
    [
        'gem_id'    =>  4,
        'name'      => 'Canon EF 100mm f/2.8L Macro IS USM',
        'price' => 10000,
        'image' => '<img src="./image/Product/Canon/Canon-Lens/Canon_100mm_f2.8_Macro_01.jpg">',
        'remaining' =>  5
    ],
    [
        'gem_id'    =>  5,
        'name'      => 'Canon EF-S 24mm f/2.8 STM',
        'price' => 10000,
        'image' => '<img src="./image/Product/Canon/Canon-Lens/Canon_24mm_f2.8_stm_01.jpg">',
        'remaining' =>  5
    ],
    [
        'gem_id'    =>  6,
        'name'      => 'Canon EF 50mm f/1.8 STM',
        'price' => 10000,
        'image' => '<img src="./image/Product/Canon/Canon-Lens/Canon_50mm_f_1_8_stm_01.jpg">',
        'remaining' =>  5
    ],
    [
        'gem_id'    =>  7,
        'name'      => 'Canon EF 75-300mm f/4-5.6 IS II USM',
        'price' => 10000,
        'image' => '<img src="./image/Product/Canon/Canon-Lens/Canon_75-300mm_f4-5.6_01.jpg">',
        'remaining' =>  5
    ],
    [
        'gem_id'    =>  8,
        'name'      => 'Canon EF 70-200mm f/2.8L IS III USM',
        'price' => 10000,
        'image' => '<img src="./image/Product/Canon/Canon-Lens/Canon_70-200mm_f2.8_IS_04.jpg">',
        'remaining' =>  5
    ],
    [
        'gem_id'    =>  9,
        'name'      => 'Canon EF 100-400mm f/4.5-5.6L IS II USM',
        'price' => 10000,
        'image' => '<img src="./image/Product/Canon/Canon-Lens/Canon_100-400mm_f4.5-5.6_IS_03.jpg">',
        'remaining' =>  5
    ],
]
?>
