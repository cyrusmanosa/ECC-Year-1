<?php include_once('header.php'); ?>

<div class="Order">
    <h1>ご注文ありがとうございます。</h1>
    <p>製品が出荷された時点でお知らせメールをお送りします。</p>
</div>
<?php include_once('footer.php'); ?>